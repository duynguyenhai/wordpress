#######################################################

 Magic Zoom™
 WordPress module version v5.12.2 [v1.4.12:v4.5.24]
 
 www.magictoolbox.com
 support@magictoolbox.com

 Copyright 2014 Magic Toolbox

#######################################################

INSTALLATION:

1. Unzip the files, keeping the folder structure intact.

2. Create folder 'magiczoom' in your "/wp-content/plugins" directory.

3. Upload the 'magiczoom' folder to your "/wp-content/plugins/magiczoom" directory.

4. Upload the 'magiczoom.php' file to your "/wp-content/plugins/magiczoom" directory.

5. Activate the plugin through the 'Plugins' menu in WordPress.

6. Magic Zoom is ready to use!

7. To upgrade your version of Magic Zoom (which removes the "Please upgrade" text), buy Magic Zoom and overwrite the wp-content/plugins/magiczoom/magiczoom/core/magiczoom.js file file with the new one in your licensed version.

Buy a single license here:

http://www.magictoolbox.com/buy/magiczoom/

Or apply for a free license if your site is non-commercial:

http://www.magictoolbox.com/license/#free

